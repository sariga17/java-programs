import java.util.Scanner;

class Student {
    private String name;
    private double homeworkGrade;
    private double finalExamGrade;

    public Student(String name, double homeworkGrade, double finalExamGrade) {
        this.name = name;
        this.homeworkGrade = homeworkGrade;
        this.finalExamGrade = finalExamGrade;
    }

    public double calculateAverage() {
        return (homeworkGrade + finalExamGrade) / 2;
    }

    public void displayStudentDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("Homework Grade: " + homeworkGrade);
        System.out.println("Final Exam Grade: " + finalExamGrade);
        System.out.println("Average Grade: " + calculateAverage());
    }
}

public class Homework {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Name: ");
        String name = scanner.nextLine();
        
        System.out.print("Homework Grade: ");
        while (!scanner.hasNextDouble()) {
            System.out.println("Invalid input. Please enter a valid number for Homework Grade.");
            scanner.next(); 
        }
        double homeworkGrade = scanner.nextDouble();
        
        System.out.print("Final Exam Grade: ");
        while (!scanner.hasNextDouble()) {
            System.out.println("Invalid input. Please enter a valid number for Final Exam Grade.");
            scanner.next(); 
        }
        double finalExamGrade = scanner.nextDouble();
        
        scanner.nextLine(); 
        
        Student student = new Student(name, homeworkGrade, finalExamGrade);
        System.out.println();
        student.displayStudentDetails();
    }
}
