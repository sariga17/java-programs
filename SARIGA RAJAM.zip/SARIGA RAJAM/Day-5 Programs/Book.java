import java.util.Scanner;


class Book {
    private String title;
    private String author;
    private double price;
    private int numberOfCopies;
    public void getDetailsFromUser() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter book title: ");
        this.title = scanner.nextLine();
        
        System.out.print("Enter book author: ");
        this.author = scanner.nextLine();
        
        System.out.print("Enter book price: ");
        this.price = scanner.nextDouble();
        
        System.out.print("Enter number of copies: ");
        this.numberOfCopies = scanner.nextInt();
    }
    public void displayDetails() {
        System.out.println("Book Title: " + title);
        System.out.println("Book Author: " + author);
        System.out.println("Book Price: " + price);
        System.out.println("Number of Copies: " + numberOfCopies);
    }
}

public class Books {
    public static void main(String[] args) {
        Book[] books = new Book[3]; 
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter details for book " + (i + 1) + ":");
            books[i] = new Book();
            books[i].getDetailsFromUser();
            System.out.println();
        }
        System.out.println("Books in the inventory:");
        for (Book book : books) {
            book.displayDetails();
            System.out.println(); 
        }
    }
}
