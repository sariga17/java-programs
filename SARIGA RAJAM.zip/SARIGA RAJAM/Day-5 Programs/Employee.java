import java.util.Scanner;

class Employee {
    private String name;
    private int id;
    private double basicSalary;
    private double allowances;
    public Employee() {
        this.name = "";
        this.id = 0;
        this.basicSalary = 0.0;
        this.allowances = 0.0;
    }
    public Employee(String name, int id, double basicSalary, double allowances) {
        this.name = name;
        this.id = id;
        this.basicSalary = basicSalary;
        this.allowances = allowances;
    }
    public double calculateGrossSalary() {
        return basicSalary + allowances;
    }

    public void displayEmployeeDetails() {
        System.out.println("Employee Name: " + name);
        System.out.println("Employee ID: " + id);
        System.out.println("Basic Salary: $" + basicSalary);
        System.out.println("Allowances: $" + allowances);
        System.out.println("Gross Salary: $" + calculateGrossSalary());
        System.out.println();
    }
}

public class EmployeeSalaryManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of employees: ");
        int numberOfEmployees = scanner.nextInt();
        scanner.nextLine(); 
        Employee[] employees = new Employee[numberOfEmployees];
        for (int i = 0; i < numberOfEmployees; i++) {
            System.out.println("Enter details for Employee " + (i + 1) + ":");
            
            System.out.print("Name: ");
            String name = scanner.nextLine();
            
            System.out.print("ID: ");
            int id = scanner.nextInt();
            
            System.out.print("Basic Salary: ");
            double basicSalary = scanner.nextDouble();
            
            System.out.print("Allowances: ");
            double allowances = scanner.nextDouble();
            scanner.nextLine(); 
            employees[i] = new Employee(name, id, basicSalary, allowances);
        }
        System.out.println("\nEmployee Details and Gross Salaries:");
        for (Employee employee : employees) {
            employee.displayEmployeeDetails();
        }

        scanner.close();
    }
}
